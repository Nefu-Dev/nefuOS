nefu-hello: nefuOS .deb environment demo.
